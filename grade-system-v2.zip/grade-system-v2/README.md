# Student Grade Management System
Frontend: HTML + CSS + JavaScript   |   Backend: Java (Spring Boot, Maven)

## Folder structure
src/main/java/com/example/grades/        <- BACKEND (Java)
    StudentGradeApplication.java         (server start)
    controller/StudentController.java    (REST API: /api/...)
    service/StudentService.java          (students ki list, stats)
    model/Student.java                   (OOP class: total, average, grade)
    util/GradeCalculator.java            (marks -> grade)
src/main/resources/static/               <- FRONTEND
    index.html, style.css, app.js        (app.js Java API ko call karta hai)

## Run
1. IntelliJ/Eclipse me Maven project ki tarah open karo.
2. StudentGradeApplication.java run karo.
3. Browser: http://localhost:8080

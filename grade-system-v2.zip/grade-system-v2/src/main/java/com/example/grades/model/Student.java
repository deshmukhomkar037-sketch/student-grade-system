package com.example.grades.model;

import com.example.grades.util.GradeCalculator;

/** Student model (OOP: encapsulation). Marks array me store hote hai. */
public class Student {

    private final int rollNo;
    private final String name;
    private final double[] marks;
    private final double total;
    private final double average;
    private final String grade;
    private final boolean passed;

    public Student(int rollNo, String name, double[] marks) {
        this.rollNo = rollNo;
        this.name = name;
        this.marks = marks;

        double sum = 0;
        boolean allPassed = true;
        for (double m : marks) {
            sum += m;
            if (m < GradeCalculator.PASS_MARK) {
                allPassed = false; // kisi ek subject me fail = overall fail
            }
        }
        this.total = sum;
        this.average = sum / marks.length;
        this.passed = allPassed;
        this.grade = allPassed ? GradeCalculator.getGrade(average) : "F";
    }

    /** Har subject ka grade (marks ke same order me). */
    public String[] getSubjectGrades() {
        String[] grades = new String[marks.length];
        for (int i = 0; i < marks.length; i++) {
            grades[i] = GradeCalculator.getGrade(marks[i]);
        }
        return grades;
    }

    public int getRollNo()     { return rollNo; }
    public String getName()    { return name; }
    public double[] getMarks() { return marks; }
    public double getTotal()   { return total; }
    public double getAverage() { return average; }
    public String getGrade()   { return grade; }
    public boolean isPassed()  { return passed; }
}

package com.example.grades.controller;

import com.example.grades.model.Student;
import com.example.grades.service.StudentService;
import com.example.grades.util.GradeCalculator;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * REST API. Frontend (static/app.js) in URLs ko call karta hai.
 */
@RestController
@RequestMapping("/api")
public class StudentController {

    // Frontend se aane wala JSON isme convert hota hai
    public record StudentRequest(Integer rollNo, String name, double[] marks) { }
    public record SubjectsRequest(List<String> subjects) { }

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    /** Sab data ek saath: subjects, students aur stats. */
    @GetMapping("/data")
    public Map<String, Object> getData() {
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("count", service.getStudents().size());
        stats.put("classAverage", service.getClassAverage());
        stats.put("passed", service.getPassedCount());
        stats.put("topper", service.getTopper());

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("subjects", service.getSubjects());
        data.put("students", service.getStudents());
        data.put("stats", stats);
        return data;
    }

    @PostMapping("/subjects")
    public ResponseEntity<?> setSubjects(@RequestBody SubjectsRequest req) {
        List<String> list = new ArrayList<>();
        if (req.subjects() != null) {
            for (String s : req.subjects()) {
                if (s != null && !s.trim().isEmpty()) list.add(s.trim());
            }
        }
        if (list.isEmpty()) {
            return error("Kam se kam ek subject daalo.");
        }
        service.setSubjects(list);
        return ResponseEntity.ok(Map.of("ok", true));
    }

    @PostMapping("/students")
    public ResponseEntity<?> addStudent(@RequestBody StudentRequest req) {
        if (req.rollNo() == null || req.rollNo() < 1) {
            return error("Valid roll number daalo.");
        }
        if (service.rollExists(req.rollNo())) {
            return error("Ye roll number pehle se hai.");
        }
        if (req.name() == null || req.name().trim().isEmpty()) {
            return error("Student ka naam daalo.");
        }
        List<String> subjects = service.getSubjects();
        if (req.marks() == null || req.marks().length != subjects.size()) {
            return error("Sab subjects ke marks daalo.");
        }
        for (int i = 0; i < req.marks().length; i++) {
            double m = req.marks()[i];
            if (Double.isNaN(m) || m < 0 || m > 100) {
                return error(subjects.get(i) + " ke marks 0 se 100 ke beech hone chahiye.");
            }
        }

        // Grade yahi Java me calculate hota hai (Student constructor + GradeCalculator)
        Student s = new Student(req.rollNo(), req.name().trim(), req.marks());
        service.addStudent(s);
        return ResponseEntity.ok(s);
    }

    @DeleteMapping("/students/{rollNo}")
    public Map<String, Object> deleteStudent(@PathVariable int rollNo) {
        service.deleteByRoll(rollNo);
        return Map.of("ok", true);
    }

    @DeleteMapping("/students")
    public Map<String, Object> clearAll() {
        service.clearAll();
        return Map.of("ok", true);
    }

    private ResponseEntity<Map<String, String>> error(String msg) {
        return ResponseEntity.badRequest().body(Map.of("error", msg));
    }
}

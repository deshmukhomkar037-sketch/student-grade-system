package com.example.grades.service;

import com.example.grades.model.Student;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Students ki list aur subjects yaha store hote hai (memory me). */
@Service
public class StudentService {

    private List<String> subjects = new ArrayList<>(Arrays.asList("Maths", "Physics", "Chemistry"));
    private final List<Student> students = new ArrayList<>();

    public List<String> getSubjects() { return subjects; }

    public void setSubjects(List<String> newSubjects) {
        this.subjects = new ArrayList<>(newSubjects);
        students.clear(); // subjects badle to purana data valid nahi
    }

    public List<Student> getStudents() { return students; }

    public boolean rollExists(int rollNo) {
        for (Student s : students) {
            if (s.getRollNo() == rollNo) return true;
        }
        return false;
    }

    public void addStudent(Student s) { students.add(s); }

    public void deleteByRoll(int rollNo) { students.removeIf(s -> s.getRollNo() == rollNo); }

    public void clearAll() { students.clear(); }

    public double getClassAverage() {
        if (students.isEmpty()) return 0;
        double sum = 0;
        for (Student s : students) sum += s.getAverage();
        return sum / students.size();
    }

    public long getPassedCount() {
        return students.stream().filter(Student::isPassed).count();
    }

    public Student getTopper() {
        Student top = null;
        for (Student s : students) {
            if (top == null || s.getAverage() > top.getAverage()) top = s;
        }
        return top;
    }
}

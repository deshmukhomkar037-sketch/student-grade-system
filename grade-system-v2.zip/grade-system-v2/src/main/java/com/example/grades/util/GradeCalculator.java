package com.example.grades.util;

/** Marks ko grade me convert karne ka utility class. */
public class GradeCalculator {

    public static final double PASS_MARK = 35.0; // har subject me minimum

    private GradeCalculator() { }

    public static String getGrade(double marks) {
        if (marks >= 90) return "A+";
        else if (marks >= 80) return "A";
        else if (marks >= 70) return "B";
        else if (marks >= 60) return "C";
        else if (marks >= 50) return "D";
        else if (marks >= PASS_MARK) return "E";
        else return "F";
    }
}

// Ye file Java backend ke REST API (/api/...) ko call karti hai.

const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

let subjects = [];
let lastSubjectsKey = "";

// Common helper: server ko request bhejta hai, error aaye to message throw karta hai
async function api(url, method = "GET", body) {
  const opt = { method, headers: {} };
  if (body !== undefined) {
    opt.headers["Content-Type"] = "application/json";
    opt.body = JSON.stringify(body);
  }
  const res = await fetch(url, opt);
  let data = null;
  try { data = await res.json(); } catch (e) { /* empty response */ }
  if (!res.ok) throw new Error((data && data.error) || "Server error");
  return data;
}

async function loadData() {
  try {
    const d = await api("/api/data");
    subjects = d.subjects;
    renderForm();
    renderTable(d.students);
    renderStats(d.stats);
  } catch (e) {
    $("err").textContent = "Backend se connect nahi ho paya. Java server chal raha hai?";
  }
}

function renderForm() {
  const key = subjects.join("|");
  if (key === lastSubjectsKey) return; // typed marks na ude
  lastSubjectsKey = key;
  $("subjects").value = subjects.join(", ");
  $("marksRow").innerHTML = subjects.map((s, i) =>
    `<div><label for="m${i}">${esc(s)} (0-100)</label>` +
    `<input id="m${i}" type="number" min="0" max="100" step="0.01"></div>`).join("");
}

function renderTable(students) {
  $("thead").innerHTML = "<tr><th>Roll</th><th>Name</th>" +
    subjects.map(s => `<th>${esc(s)}</th>`).join("") +
    "<th>Total</th><th>Average</th><th>Grade</th><th>Result</th><th></th></tr>";

  if (!students.length) {
    $("tbody").innerHTML = `<tr><td class="empty" colspan="${subjects.length + 7}">Abhi koi student nahi hai.</td></tr>`;
    return;
  }
  $("tbody").innerHTML = students.map(s =>
    `<tr><td>${s.rollNo}</td><td>${esc(s.name)}</td>` +
    s.marks.map((m, i) => `<td>${m} <span class="small">(${s.subjectGrades[i]})</span></td>`).join("") +
    `<td>${s.total.toFixed(2)}</td><td>${s.average.toFixed(2)}</td>` +
    `<td><b>${s.grade}</b></td>` +
    `<td class="${s.passed ? "pass" : "fail"}">${s.passed ? "PASS" : "FAIL"}</td>` +
    `<td><button class="del" data-roll="${s.rollNo}" aria-label="Delete">✕</button></td></tr>`).join("");
}

function renderStats(st) {
  if (!st.count) { $("stats").innerHTML = ""; return; }
  $("stats").innerHTML =
    `<div class="stat"><b>${st.count}</b><span>Students</span></div>` +
    `<div class="stat"><b>${st.classAverage.toFixed(2)}</b><span>Class average</span></div>` +
    `<div class="stat"><b>${st.passed} / ${st.count}</b><span>Passed</span></div>` +
    `<div class="stat"><b>${esc(st.topper.name)}</b><span>Topper (${st.topper.average.toFixed(2)}, ${st.topper.grade})</span></div>`;
}

// ---------- Button actions ----------
$("setSubjects").onclick = async () => {
  const list = $("subjects").value.split(",").map(s => s.trim()).filter(Boolean);
  if (subjects.length && !confirm("Isse sab students clear ho jayenge. Continue?")) return;
  try {
    await api("/api/subjects", "POST", { subjects: list });
    $("err").textContent = "";
    lastSubjectsKey = "";
    loadData();
  } catch (e) { $("err").textContent = e.message; }
};

$("add").onclick = async () => {
  const marks = subjects.map((_, i) => parseFloat($("m" + i).value));
  if (marks.some(isNaN)) { $("err").textContent = "Sab subjects ke marks daalo."; return; }
  const body = {
    rollNo: parseInt($("roll").value, 10) || null,
    name: $("name").value,
    marks: marks
  };
  try {
    await api("/api/students", "POST", body);
    $("err").textContent = "";
    $("roll").value = ""; $("name").value = "";
    subjects.forEach((_, i) => $("m" + i).value = "");
    loadData();
    $("roll").focus();
  } catch (e) { $("err").textContent = e.message; }
};

$("clear").onclick = async () => {
  if (!confirm("Sab students delete karne hai?")) return;
  await api("/api/students", "DELETE");
  loadData();
};

$("tbody").onclick = async e => {
  const b = e.target.closest("button[data-roll]");
  if (!b) return;
  await api("/api/students/" + b.dataset.roll, "DELETE");
  loadData();
};

loadData();
